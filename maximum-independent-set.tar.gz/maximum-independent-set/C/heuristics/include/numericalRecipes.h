#ifndef _NUMERICAL_RECIPES_HEADER_
#define _NUMERICAL_RECIPES_HEADER_


void   quickSort(double *, int *, int, int);
int    iDot(int **x, int dim);
double iNorm(int **x, int dim);

#endif
